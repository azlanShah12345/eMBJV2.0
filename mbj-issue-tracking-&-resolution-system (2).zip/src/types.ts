export interface User {
  id: number;
  username: string;
  role: 'ADMIN' | 'USER';
  department_name: string;
  department_id: number;
}

export interface Department {
  id: number;
  name: string;
}

export interface Meeting {
  id: number;
  bil_mesyuarat: string;
  tarikh_mesyuarat: string;
  minit_path: string | null;
  department_id: number;
  department_name: string;
  is_locked: number;
  unlock_requested: number;
  delete_requested: number;
  created_by: number;
  creator_name: string;
  created_at: string;
  total_issues: number;
  completed_issues: number;
}

export interface Issue {
  id: number;
  meeting_id: number;
  category: string;
  is_from_previous: number;
  title: string;
  status: 'Selesai' | 'Belum Selesai';
  responsible_officer: string;
  updated_at: string;
}

export interface CategoryStats {
  category: string;
  total: number;
  selesai: number;
  belum_selesai: number;
}

export const CATEGORIES = [
  'Kewangan dan Kemudahan',
  'Pentadbiran',
  'Sumber Manusia',
  'Kebajikan',
  'Inovasi dan Produktiviti',
  'Lain-lain'
];
