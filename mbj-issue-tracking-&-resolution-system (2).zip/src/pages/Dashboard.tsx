import { useState, useEffect } from 'react';
import { api } from '../services/api';
import { CategoryStats, Department, CATEGORIES, Meeting } from '../types';
import { Filter, Download, PieChart, BarChart3, TrendingUp, Users, FileSpreadsheet, FileJson, Lock, CheckCircle2, XCircle, Trash2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useToast } from '../components/Toast';
import ConfirmModal from '../components/ConfirmModal';
import { jsPDF } from 'jspdf';
import 'jspdf-autotable';
import * as XLSX from 'xlsx';

export default function Dashboard() {
  const { showToast } = useToast();
  const [stats, setStats] = useState<CategoryStats[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [pendingUnlocks, setPendingUnlocks] = useState<Meeting[]>([]);
  const [pendingDeletes, setPendingDeletes] = useState<Meeting[]>([]);
  const [loading, setLoading] = useState(true);
  const [confirmConfig, setConfirmConfig] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
    isDanger?: boolean;
  }>({
    isOpen: false,
    title: '',
    message: '',
    onConfirm: () => {}
  });

  // Filters
  const [deptId, setDeptId] = useState('');
  const [bil, setBil] = useState('');

  useEffect(() => {
    fetchInitialData();
  }, []);

  useEffect(() => {
    fetchStats();
  }, [deptId, bil]);

  const fetchInitialData = async () => {
    try {
      const [depts, allMeetings] = await Promise.all([
        api.getDepartments(),
        api.getMeetings()
      ]);
      setDepartments(depts);
      setPendingUnlocks(allMeetings.filter(m => m.unlock_requested === 1));
      setPendingDeletes(allMeetings.filter(m => m.delete_requested === 1));
    } catch (err) {
      console.error(err);
    }
  };

  const handleApproveUnlock = (id: number) => {
    setConfirmConfig({
      isOpen: true,
      title: 'Approve Unlock',
      message: 'Approve this unlock request?',
      onConfirm: async () => {
        setConfirmConfig(prev => ({ ...prev, isOpen: false }));
        try {
          await api.approveUnlock(id);
          showToast('Unlock request approved');
          fetchInitialData();
        } catch (err) {
          showToast('Failed to approve unlock', 'error');
        }
      }
    });
  };

  const handleApproveDelete = (id: number) => {
    setConfirmConfig({
      isOpen: true,
      title: 'Approve Delete',
      message: 'Approve this delete request? This will PERMANENTLY remove the record.',
      isDanger: true,
      onConfirm: async () => {
        setConfirmConfig(prev => ({ ...prev, isOpen: false }));
        try {
          await api.approveDeleteMeeting(id);
          showToast('Meeting record deleted');
          fetchInitialData();
        } catch (err) {
          showToast('Failed to approve delete', 'error');
        }
      }
    });
  };

  const fetchStats = async () => {
    setLoading(true);
    try {
      const data = await api.getStats({ 
        department_id: deptId ? Number(deptId) : undefined, 
        bil_mesyuarat: bil || undefined 
      });
      setStats(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const totalIssues = stats.reduce((acc, s) => acc + s.total, 0);
  const totalSelesai = stats.reduce((acc, s) => acc + s.selesai, 0);
  const completionRate = totalIssues > 0 ? (totalSelesai / totalIssues) * 100 : 0;

  const exportPDF = () => {
    const doc = new jsPDF() as any;
    doc.setFontSize(18);
    doc.text('MBJ Issue Tracking & Resolution Report', 14, 22);
    doc.setFontSize(11);
    doc.setTextColor(100);
    doc.text(`Generated on: ${new Date().toLocaleDateString('ms-MY')}`, 14, 30);
    doc.text(`Department: ${departments.find(d => d.id === Number(deptId))?.name || 'All'}`, 14, 36);
    doc.text(`Meeting: ${bil || 'All'}`, 14, 42);

    const tableData = stats.map(s => [
      s.category,
      s.total,
      s.selesai,
      s.belum_selesai,
      `${s.total > 0 ? ((s.selesai / s.total) * 100).toFixed(1) : 0}%`
    ]);

    doc.autoTable({
      startY: 50,
      head: [['Category', 'Total', 'Selesai', 'Belum Selesai', 'Completion %']],
      body: tableData,
      theme: 'grid',
      headStyles: { fillColor: [15, 23, 42] }
    });

    doc.save('MBJ-Report.pdf');
  };

  const exportExcel = () => {
    const worksheet = XLSX.utils.json_to_sheet(stats.map(s => ({
      'Category': s.category,
      'Total Issues': s.total,
      'Selesai': s.selesai,
      'Belum Selesai': s.belum_selesai,
      'Completion %': s.total > 0 ? ((s.selesai / s.total) * 100).toFixed(1) : 0
    })));
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "MBJ Report");
    XLSX.writeFile(workbook, "MBJ-Report.xlsx");
  };

  return (
    <div className="space-y-8">
      <ConfirmModal
        isOpen={confirmConfig.isOpen}
        title={confirmConfig.title}
        message={confirmConfig.message}
        isDanger={confirmConfig.isDanger}
        onConfirm={confirmConfig.onConfirm}
        onCancel={() => setConfirmConfig(prev => ({ ...prev, isOpen: false }))}
      />

      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">HQ Summary Dashboard</h2>
          <p className="text-slate-500">Real-time tracking of issue resolution across all departments.</p>
        </div>
        <div className="flex gap-3">
          <button 
            onClick={exportExcel}
            className="flex items-center gap-2 bg-white border border-slate-200 text-slate-700 px-4 py-2 rounded-lg font-medium hover:bg-slate-50 transition-colors"
          >
            <FileSpreadsheet size={18} />
            Excel
          </button>
          <button 
            onClick={exportPDF}
            className="flex items-center gap-2 bg-slate-900 text-white px-4 py-2 rounded-lg font-medium hover:bg-slate-800 transition-colors"
          >
            <Download size={18} />
            PDF Report
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-wrap gap-6 items-end">
        <div className="flex-1 min-w-[200px]">
          <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2 flex items-center gap-2">
            <Users size={14} /> Department
          </label>
          <select 
            value={deptId}
            onChange={(e) => setDeptId(e.target.value)}
            className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-emerald-500"
          >
            <option value="">All Departments</option>
            {departments.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
          </select>
        </div>
        <div className="flex-1 min-w-[200px]">
          <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2 flex items-center gap-2">
            <Filter size={14} /> Meeting Number
          </label>
          <select 
            value={bil}
            onChange={(e) => setBil(e.target.value)}
            className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-emerald-500"
          >
            <option value="">All Meetings</option>
            <option>Bil 1</option>
            <option>Bil 2</option>
            <option>Bil 3</option>
          </select>
        </div>
        <button 
          onClick={() => { setDeptId(''); setBil(''); }}
          className="px-6 py-2.5 text-slate-500 font-medium hover:text-slate-800 transition-colors"
        >
          Reset Filters
        </button>
      </div>

      {/* Pending Requests */}
      {(pendingUnlocks.length > 0 || pendingDeletes.length > 0) && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {pendingUnlocks.length > 0 && (
            <div className="bg-indigo-50 border border-indigo-100 rounded-2xl p-6">
              <div className="flex items-center gap-2 mb-4">
                <Lock className="text-indigo-600" size={20} />
                <h3 className="font-bold text-indigo-900 text-lg">Unlock Requests</h3>
              </div>
              <div className="space-y-3">
                {pendingUnlocks.map(m => (
                  <div key={m.id} className="bg-white p-4 rounded-xl border border-indigo-200 shadow-sm flex justify-between items-center">
                    <div>
                      <Link to={`/meeting/${m.id}`} className="font-bold text-slate-800 hover:text-indigo-600 transition-colors">
                        {m.bil_mesyuarat}
                      </Link>
                      <p className="text-xs text-slate-500">{m.department_name}</p>
                    </div>
                    <button 
                      onClick={() => handleApproveUnlock(m.id)}
                      className="bg-indigo-600 text-white px-3 py-1.5 rounded-lg text-xs font-bold hover:bg-indigo-700 transition-colors flex items-center gap-1"
                    >
                      <CheckCircle2 size={14} /> Approve
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {pendingDeletes.length > 0 && (
            <div className="bg-red-50 border border-red-100 rounded-2xl p-6">
              <div className="flex items-center gap-2 mb-4">
                <Trash2 className="text-red-600" size={20} />
                <h3 className="font-bold text-red-900 text-lg">Delete Requests</h3>
              </div>
              <div className="space-y-3">
                {pendingDeletes.map(m => (
                  <div key={m.id} className="bg-white p-4 rounded-xl border border-red-200 shadow-sm flex justify-between items-center">
                    <div>
                      <Link to={`/meeting/${m.id}`} className="font-bold text-slate-800 hover:text-red-600 transition-colors">
                        {m.bil_mesyuarat}
                      </Link>
                      <p className="text-xs text-slate-500">{m.department_name}</p>
                    </div>
                    <button 
                      onClick={() => handleApproveDelete(m.id)}
                      className="bg-red-600 text-white px-3 py-1.5 rounded-lg text-xs font-bold hover:bg-red-700 transition-colors flex items-center gap-1"
                    >
                      <CheckCircle2 size={14} /> Approve
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-sm relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-4 text-emerald-100 group-hover:text-emerald-500 transition-colors">
            <TrendingUp size={64} />
          </div>
          <p className="text-slate-400 text-sm font-bold uppercase tracking-widest mb-1">Overall Completion</p>
          <h3 className="text-4xl font-black text-slate-900">{completionRate.toFixed(1)}%</h3>
          <div className="mt-4 w-full bg-slate-100 h-2 rounded-full overflow-hidden">
            <div className="bg-emerald-500 h-full transition-all duration-1000" style={{ width: `${completionRate}%` }} />
          </div>
        </div>

        <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-sm relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-4 text-indigo-100 group-hover:text-indigo-500 transition-colors">
            <BarChart3 size={64} />
          </div>
          <p className="text-slate-400 text-sm font-bold uppercase tracking-widest mb-1">Total Issues</p>
          <h3 className="text-4xl font-black text-slate-900">{totalIssues}</h3>
          <p className="text-slate-500 text-sm mt-2">Across all categories</p>
        </div>

        <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-sm relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-4 text-amber-100 group-hover:text-amber-500 transition-colors">
            <PieChart size={64} />
          </div>
          <p className="text-slate-400 text-sm font-bold uppercase tracking-widest mb-1">Pending Resolution</p>
          <h3 className="text-4xl font-black text-slate-900">{totalIssues - totalSelesai}</h3>
          <p className="text-slate-500 text-sm mt-2">Requires attention</p>
        </div>
      </div>

      {/* Category Breakdown */}
      <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-sm">
        <div className="p-6 border-b border-slate-100 flex justify-between items-center">
          <h3 className="font-bold text-slate-800">Category Breakdown</h3>
          <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">Detailed Report</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 text-slate-500 text-xs font-bold uppercase tracking-widest">
                <th className="px-8 py-4">Category</th>
                <th className="px-8 py-4">Total</th>
                <th className="px-8 py-4">Selesai</th>
                <th className="px-8 py-4">Belum Selesai</th>
                <th className="px-8 py-4">Progress</th>
                <th className="px-8 py-4 text-right">%</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {loading ? (
                <tr><td colSpan={6} className="px-8 py-12 text-center text-slate-400">Loading stats...</td></tr>
              ) : stats.length === 0 ? (
                <tr><td colSpan={6} className="px-8 py-12 text-center text-slate-400 italic">No data available for selected filters.</td></tr>
              ) : (
                stats.map((s) => (
                  <tr key={s.category} className="hover:bg-slate-50/50 transition-colors">
                    <td className="px-8 py-5 font-bold text-slate-700">{s.category}</td>
                    <td className="px-8 py-5 text-slate-600 font-medium">{s.total}</td>
                    <td className="px-8 py-5 text-emerald-600 font-bold">{s.selesai}</td>
                    <td className="px-8 py-5 text-amber-600 font-bold">{s.belum_selesai}</td>
                    <td className="px-8 py-5 min-w-[150px]">
                      <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                        <div 
                          className="bg-emerald-500 h-full transition-all duration-500" 
                          style={{ width: `${s.total > 0 ? (s.selesai / s.total) * 100 : 0}%` }}
                        />
                      </div>
                    </td>
                    <td className="px-8 py-5 text-right font-black text-slate-900">
                      {s.total > 0 ? ((s.selesai / s.total) * 100).toFixed(1) : 0}%
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
